package com.aguspribadi.kopikenangan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private RecyclerView rvMinuman;
    private ImageView btnProfile;
    private ArrayList<Minuman> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnProfile = (ImageView) findViewById(R.id.btn_profil);
        btnProfile.setOnClickListener(this);
        rvMinuman = findViewById(R.id.rv_makanan);
        rvMinuman.setHasFixedSize(true);
        list.addAll(MinumanData.getListData());
        showRecyclerCardView();
    }

    @Override
    public void onClick(View v){
        Intent profile;

        switch (v.getId()){
            case R.id.btn_profil : profile = new Intent(this, ActivityProfile.class); startActivity(profile); break;
            default:break;
        }
    }

    private void showRecyclerCardView(){
        rvMinuman.setLayoutManager(new LinearLayoutManager(this));
        CardViewMinumanAdapter cardViewHeroAdapter = new CardViewMinumanAdapter(list);
        rvMinuman.setAdapter(cardViewHeroAdapter);
        cardViewHeroAdapter.setOnItemClickCallback(new CardViewMinumanAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(Minuman data) {
                Intent moveIntent = new Intent(MainActivity.this, Detail.class);
                moveIntent.putExtra(Detail.EXTRA_NAMA, data.getNama());
                moveIntent.putExtra(Detail.EXTRA_DESKRIPSI, data.getDeskripsi());
                moveIntent.putExtra(Detail.EXTRA_HARGA, data.getHarga());
                moveIntent.putExtra(Detail.EXTRA_GAMBAR, data.getPhoto());
                startActivity(moveIntent);
            }
        });
    }
}
