package com.aguspribadi.kopikenangan;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class Detail extends AppCompatActivity {
    private ImageView imgPhoto;
    private TextView tvNama, tvDeskripsi, tvHarga;
    public static final String EXTRA_NAMA = "extra_nama";
    public static final String EXTRA_DESKRIPSI = "extra_deskripsi";
    public static final String EXTRA_HARGA = "extra_harga";
    public static final String EXTRA_GAMBAR = "extra_gambar";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String nama = getIntent().getStringExtra(EXTRA_NAMA);
        String deskripsi = getIntent().getStringExtra(EXTRA_DESKRIPSI);
        String harga = getIntent().getStringExtra(EXTRA_HARGA);
        int gambar = getIntent().getIntExtra(EXTRA_GAMBAR, 0);
        setContentView(R.layout.activity_detail);
        imgPhoto = findViewById(R.id.img_photo);
        tvNama = findViewById(R.id.tv_item_makanan);
        tvDeskripsi = findViewById(R.id.tv_item_deskripsi);
        tvHarga = findViewById(R.id.tv_item_harga);
        Glide.with(this)
                .load(gambar)
                .into(imgPhoto);
        tvNama.setText(nama);
        tvDeskripsi.setText(deskripsi);
        tvHarga.setText(harga);
    }

    public void pesan(View view) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(Detail.this);
        alertDialog.setTitle("Minuman Terpesan");
        alertDialog.setMessage("Barista segera menyiapkan minumanmu");
        alertDialog.show();
    }
}
