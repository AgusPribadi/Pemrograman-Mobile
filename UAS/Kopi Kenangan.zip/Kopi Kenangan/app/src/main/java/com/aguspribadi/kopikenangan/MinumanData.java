package com.aguspribadi.kopikenangan;

import java.util.ArrayList;

public class MinumanData {
    private static String[] namaMinuman = {
            "Kopi Kenangan Mantan",
            "Kopi Kelapa",
            "Salted Caramel Macchiato",
            "Susu Sultan Boba Gula Aren",
            "Thai Tea"
    };
    private static String[] deskripsiMinuman = {
            "Kopi Kenangan Mantan menjadi signature menu di Kopi Kenangan yang wajib kamu coba. Pada dasarnya, kopi ini terbuat dari kopi susu dengan gula aren yang biasanya selalu ada di kedai kopi manapun.\n" +
                    "\n" +
                    "Tapi, rasa manis yang khas dari gula aren yang berpadu dengan pahitnya kopi membuat menu ini spesial. Kamu juga bisa menambahkan topping Sultan Boba yang kenyal agar semakin nikmat.",
            "Menu yang satu ini cukup unik dan jarang dijumpai di kedai kopi lainnya. Kopi Kelapa terbuat dari espresso dengan air kelapa. Rasanya yang unik dapat menyegarkan kamu di siang hari!",
            "Salah satu menu kopi yang best seller adalah Salted Caramel Macchiato. Minuman ini terbuat dari espresso, susu, dan saus karamel. Perpaduan rasanya yang manis, creamy, dan gurih cocok untuk kamu yang tidak terlalu suka dengan kopi pahit. Must try!",
            "Pilihan menu non kopi yang menjadi favorit banyak orang adalah Susu Sultan Boba Gula Aren yang terbuat dari paduan susu yang creamy, boba kenyal, dengan gula aren yang manis. Meski sederhana, rasanya pas dan nikmat.",
            "Walaupun menu utama Kopi Kenangan adalah kopi, tapi menu-menu non kopinya juga enak, loh! Seperti Thai Tea, yang memiliki rasa pahit manis dan wangi dari tehnya. Thai Tea Kopi Kenangan tak kalah dari brand Thai Tea terkenal lainnya."
    };
    private static int[] gambarMinuman = {
            R.drawable.kopikenanganmantan,
            R.drawable.kopikelapa,
            R.drawable.saltedcaramelmacchiato,
            R.drawable.sususultanbobagulaaren,
            R.drawable.thaitea,
    };
    private static String[] hargaMinuman = {
            "Rp. 25.000",
            "Rp. 15.000",
            "Rp. 20.000",
            "Rp. 22.000",
            "Rp. 18.000"
    };
    static ArrayList<Minuman> getListData() {
        ArrayList<Minuman> list = new ArrayList<>();
        for (int position = 0; position <namaMinuman.length; position++) {
            Minuman minuman = new Minuman();
            minuman.setNama(namaMinuman[position]);
            minuman.setDeskripsi(deskripsiMinuman[position]);
            minuman.setHarga(hargaMinuman[position]);
            minuman.setPhoto(gambarMinuman[position]);
            list.add(minuman);
        }
        return list;
    }
}
